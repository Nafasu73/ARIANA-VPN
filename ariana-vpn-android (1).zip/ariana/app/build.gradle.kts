plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.ariana.vpn"
    compileSdk = 34

    defaultConfig {
        applicationId = "ir.ariana.vpn"
        minSdk = 24
        targetSdk = 33
        versionCode = 1
        versionName = "1.0.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // The Aether core is shipped as libaether.so and executed from nativeLibraryDir,
    // so the libs must be extracted to disk and must not be stripped.
    packaging {
        jniLibs {
            useLegacyPackaging = true
            keepDebugSymbols += "**/libaether.so"
        }
    }
}
