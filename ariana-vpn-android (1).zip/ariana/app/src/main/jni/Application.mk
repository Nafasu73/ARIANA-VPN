APP_ABIS := armeabi-v7a arm64-v8a
APP_PLATFORM := android-24
APP_CFLAGS := -O3 -DPKGNAME=hev/htproxy -DCLASSNAME=TProxyService
APP_LDFLAGS := -Wl,--build-id=none -Wl,--hash-style=gnu -Wl,-z,max-page-size=16384
