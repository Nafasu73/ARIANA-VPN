package ir.ariana.vpn

import android.os.Handler
import android.os.Looper

enum class Conn { OFF, CONNECTING, ON }

object VpnState {
    @Volatile var conn = Conn.OFF
    @Volatile var message = ""
    @Volatile var since = 0L
    @Volatile var tx = 0L
    @Volatile var rx = 0L
    @Volatile var listener: (() -> Unit)? = null

    private val log = ArrayDeque<String>()
    private val h = Handler(Looper.getMainLooper())

    fun addLog(s: String) {
        synchronized(log) {
            log.addLast(s)
            if (log.size > 300) log.removeFirst()
        }
    }

    fun logText(): String = synchronized(log) { log.joinToString("\n") }

    fun set(c: Conn, msg: String = "") {
        conn = c
        message = msg
        if (c == Conn.OFF) { since = 0L; tx = 0L; rx = 0L }
        notifyChanged()
    }

    fun notifyChanged() { h.post { listener?.invoke() } }
}
