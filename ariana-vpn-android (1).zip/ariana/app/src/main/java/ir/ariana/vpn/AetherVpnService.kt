package ir.ariana.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import hev.htproxy.TProxyService
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

class AetherVpnService : VpnService() {

    companion object {
        const val EXTRA_ARGS = "args"
        const val EXTRA_IG = "ig"
        const val SOCKS_PORT = 1819
        private const val CH = "ariana"
    }

    private var proc: Process? = null
    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    @Volatile private var running = false
    @Volatile private var hevStarted = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY
        running = true
        startFg()
        val args = intent?.getStringArrayListExtra(EXTRA_ARGS) ?: arrayListOf()
        val ig = intent?.getBooleanExtra(EXTRA_IG, false) ?: false
        VpnState.set(Conn.CONNECTING)
        worker = Thread { runTunnel(args, ig) }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun alive(p: Process): Boolean = try { p.exitValue(); false } catch (e: IllegalThreadStateException) { true }

    private fun runTunnel(args: List<String>, instagramOnly: Boolean) {
        try {
            val bin = File(applicationInfo.nativeLibraryDir, "libaether.so")
            if (!bin.exists()) throw IOException("هسته Aether داخل APK نیست")

            val pb = ProcessBuilder(listOf(bin.absolutePath) + args)
                .directory(filesDir)
                .redirectErrorStream(true)
            pb.environment().apply {
                put("HOME", filesDir.absolutePath)
                put("TMPDIR", cacheDir.absolutePath)
                put("AETHER_SOCKS", "127.0.0.1:$SOCKS_PORT")
            }
            VpnState.addLog("> aether " + args.joinToString(" "))
            val p = pb.start()
            proc = p
            Thread {
                try { p.inputStream.bufferedReader().forEachLine { VpnState.addLog(it) } } catch (_: Exception) {}
            }.start()

            // Aether opens SOCKS5 only after the tunnel is verified end-to-end.
            val end = System.currentTimeMillis() + 120_000
            var ready = false
            while (running && System.currentTimeMillis() < end) {
                if (!alive(p)) throw IOException("هسته متوقف شد (کد ${p.exitValue()})")
                try {
                    Socket().use { it.connect(InetSocketAddress("127.0.0.1", SOCKS_PORT), 400) }
                    ready = true
                    break
                } catch (_: Exception) {
                    Thread.sleep(500)
                }
            }
            if (!running) return
            if (!ready) throw IOException("زمان اتصال تمام شد؛ شبکه یا سرور را عوض کنید")

            val b = Builder()
                .setSession("Ariana VPN")
                .setMtu(1500)
                .addAddress("198.18.0.1", 32)
                .addAddress("fd00::1", 128)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")

            if (instagramOnly) {
                var n = 0
                for (pkg in Servers.instagramPackages) {
                    try { b.addAllowedApplication(pkg); n++ } catch (_: PackageManager.NameNotFoundException) {}
                }
                if (n == 0) throw IOException("اینستاگرام روی گوشی نصب نیست")
            } else {
                // Our own process (the core) must bypass the VPN, otherwise it loops.
                b.addDisallowedApplication(packageName)
            }

            val fd = b.establish() ?: throw IOException("مجوز VPN داده نشد")
            tun = fd

            val cfg = File(filesDir, "hev.yml")
            cfg.writeText(
                """
                tunnel:
                  mtu: 1500
                  ipv4: 198.18.0.1
                  ipv6: 'fd00::1'
                socks5:
                  port: $SOCKS_PORT
                  address: 127.0.0.1
                  udp: 'udp'
                misc:
                  task-stack-size: 81920
                  connect-timeout: 10000
                  read-write-timeout: 60000
                  log-level: warn
                """.trimIndent() + "\n"
            )
            TProxyService.TProxyStartService(cfg.absolutePath, fd.fd)
            hevStarted = true

            VpnState.since = System.currentTimeMillis()
            VpnState.set(Conn.ON)
            updateNotification("متصل است")
            VpnState.addLog("Connected. SOCKS5 127.0.0.1:$SOCKS_PORT -> TUN")

            while (running) {
                Thread.sleep(1000)
                if (!alive(p)) throw IOException("هسته متوقف شد (کد ${p.exitValue()})")
                try {
                    val s = TProxyService.TProxyGetStats()
                    if (s != null && s.size >= 4) { VpnState.tx = s[1]; VpnState.rx = s[3] }
                } catch (_: Throwable) {}
                VpnState.notifyChanged()
            }
        } catch (e: InterruptedException) {
            // shutting down
        } catch (e: Throwable) {
            VpnState.addLog("ERROR: ${e.message}")
            if (running) shutdown(e.message ?: "خطا در اتصال")
        }
    }

    private fun shutdown(msg: String) {
        val wasRunning = running
        running = false
        if (hevStarted) {
            try { TProxyService.TProxyStopService() } catch (_: Throwable) {}
            hevStarted = false
        }
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        proc?.destroy()
        proc = null
        VpnState.set(Conn.OFF, msg)
        if (wasRunning) {
            stopForeground(true)
            stopSelf()
        }
    }

    override fun onRevoke() { shutdown("") ; super.onRevoke() }
    override fun onDestroy() { shutdown(""); super.onDestroy() }

    private fun builder(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        return nb.setContentTitle("آریانا وی‌پی‌ان")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun startFg() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Ariana VPN", NotificationManager.IMPORTANCE_LOW))
        }
        startForeground(1, builder("در حال اتصال…"))
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, builder(text))
    }
}
