package ir.ariana.vpn

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val purple = Color.parseColor("#7B2FF7")
    private val green = Color.parseColor("#00D68F")
    private val amber = Color.parseColor("#FFB020")
    private val red = Color.parseColor("#FF4D6D")
    private val card = Color.parseColor("#1E1245")

    private lateinit var prefs: SharedPreferences
    private lateinit var statusTv: TextView
    private lateinit var msgTv: TextView
    private lateinit var hintTv: TextView
    private lateinit var powerCircle: FrameLayout
    private lateinit var powerIcon: TextView
    private lateinit var serverTv: TextView
    private lateinit var flagTv: TextView
    private lateinit var rxTv: TextView
    private lateinit var txTv: TextView
    private lateinit var igSwitch: Switch

    private val ui = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, r: Int, stroke: Int = 0, sw: Int = 0, oval: Boolean = false) =
        GradientDrawable().apply {
            if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(r).toFloat()
            setColor(fill)
            if (sw > 0) setStroke(dp(sw), stroke)
        }

    private fun tv(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ariana", Context.MODE_PRIVATE)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        VpnState.listener = { refresh() }
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        VpnState.listener = null
        ui.removeCallbacks(ticker)
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(24), dp(18), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0B0420"), Color.parseColor("#1D0B47"))
            )
        }

        // Title
        root.addView(tv("👑", 22f).apply { gravity = Gravity.CENTER })
        root.addView(tv("ARIANA VPN", 24f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        root.addView(tv("آزادانه در اینترنت بچرخید", 13f, Color.parseColor("#B9A9F0")).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(14))
        })

        // Status card
        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = rounded(card, 18, Color.parseColor("#3A2480"), 1)
        }
        statusCard.addView(tv("وضعیت اتصال", 13f, Color.parseColor("#B9A9F0")))
        statusTv = tv("قطع است", 20f, red, true)
        statusCard.addView(statusTv)
        msgTv = tv("", 12f, Color.parseColor("#FF9DB0")).apply { visibility = View.GONE }
        statusCard.addView(msgTv)
        statusCard.setOnClickListener { showLog() }
        root.addView(statusCard, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 0, 18))

        // Power button
        powerCircle = FrameLayout(this).apply {
            background = rounded(Color.parseColor("#2A1170"), 0, purple, 6, true)
            elevation = dp(12).toFloat()
            setOnClickListener { onPower() }
        }
        powerIcon = tv("⏻", 64f, Color.WHITE).apply { gravity = Gravity.CENTER }
        powerCircle.addView(powerIcon, FrameLayout.LayoutParams(-1, -1))
        root.addView(powerCircle, lp(dp(190), dp(190), 0, 6, 0, 10))

        hintTv = tv("برای اتصال کلیک کنید", 15f, Color.WHITE).apply { gravity = Gravity.CENTER }
        root.addView(hintTv, lp(-1, -2, 0, 0, 0, 16))

        // Server picker
        val serverRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(card, 16, Color.parseColor("#3A2480"), 1)
            setOnClickListener { pickServer() }
        }
        flagTv = tv("🌐", 26f)
        serverTv = tv("", 16f, Color.WHITE, true).apply { setPadding(dp(12), 0, dp(12), 0) }
        serverRow.addView(flagTv)
        serverRow.addView(serverTv, LinearLayout.LayoutParams(0, -2, 1f))
        serverRow.addView(tv("‹", 26f, Color.parseColor("#B9A9F0")))
        root.addView(serverRow, lp(-1, -2, 0, 0, 0, 10))

        // Instagram only
        val igRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = rounded(card, 16, Color.parseColor("#3A2480"), 1)
        }
        igRow.addView(tv("فقط اینستاگرام", 15f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        igSwitch = Switch(this).apply {
            isChecked = prefs.getBoolean("ig", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("ig", c).apply() }
        }
        igRow.addView(igSwitch)
        root.addView(igRow, lp(-1, -2, 0, 0, 0, 10))

        // Stats
        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(12), dp(8), dp(12))
            background = rounded(card, 16, Color.parseColor("#3A2480"), 1)
        }
        rxTv = tv("⬇ 0 B", 15f, green, true).apply { gravity = Gravity.CENTER }
        txTv = tv("⬆ 0 B", 15f, Color.parseColor("#B99CFF"), true).apply { gravity = Gravity.CENTER }
        stats.addView(rxTv, LinearLayout.LayoutParams(0, -2, 1f))
        stats.addView(txTv, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(stats, lp(-1, -2, 0, 0, 0, 14))

        root.addView(tv("طراحی و توسعه: فاطمه زهرا ساعی", 12f, Color.parseColor("#8D7BD1")).apply {
            gravity = Gravity.CENTER
        })

        return ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.parseColor("#0B0420"))
            addView(root, ViewGroup.LayoutParams(-1, -2))
        }
    }

    private fun lp(w: Int, h: Int, l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h).apply {
            setMargins(dp(l), dp(t), dp(r), dp(b))
            gravity = Gravity.CENTER_HORIZONTAL
        }

    private fun selected(): Int = prefs.getInt("server", 0).coerceIn(0, Servers.list.lastIndex)

    private fun pickServer() {
        if (VpnState.conn != Conn.OFF) return
        val names = Servers.list.map { it.flag + "  " + it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("انتخاب سرور")
            .setSingleChoiceItems(names, selected()) { d, which ->
                prefs.edit().putInt("server", which).apply()
                refresh()
                d.dismiss()
            }
            .show()
    }

    private fun showLog() {
        val t = TextView(this).apply {
            text = VpnState.logText().ifEmpty { "گزارشی وجود ندارد" }
            typeface = Typeface.MONOSPACE
            textSize = 11f
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("گزارش هسته")
            .setView(ScrollView(this).apply { addView(t) })
            .setPositiveButton("باشه", null)
            .show()
    }

    private fun onPower() {
        if (VpnState.conn == Conn.OFF) {
            val i = VpnService.prepare(this)
            if (i != null) startActivityForResult(i, 100) else startVpn()
        } else {
            stopService(Intent(this, AetherVpnService::class.java))
            VpnState.set(Conn.OFF)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        val s = Servers.list[selected()]
        val i = Intent(this, AetherVpnService::class.java)
            .putStringArrayListExtra(AetherVpnService.EXTRA_ARGS, ArrayList(s.args))
            .putExtra(AetherVpnService.EXTRA_IG, igSwitch.isChecked)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun fmt(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> "%.1f KB".format(b / 1024.0)
        b < 1024L * 1024 * 1024 -> "%.1f MB".format(b / 1048576.0)
        else -> "%.2f GB".format(b / 1073741824.0)
    }

    private fun refresh() {
        val s = Servers.list[selected()]
        serverTv.text = s.name
        flagTv.text = s.flag
        rxTv.text = "⬇ " + fmt(VpnState.rx)
        txTv.text = "⬆ " + fmt(VpnState.tx)

        val c = VpnState.conn
        igSwitch.isEnabled = c == Conn.OFF
        val ringColor: Int
        when (c) {
            Conn.OFF -> {
                statusTv.text = "قطع است"; statusTv.setTextColor(red)
                hintTv.text = "برای اتصال کلیک کنید"
                ringColor = purple
            }
            Conn.CONNECTING -> {
                statusTv.text = "در حال اتصال…"; statusTv.setTextColor(amber)
                hintTv.text = "کمی صبر کنید (تا ۲ دقیقه)"
                ringColor = amber
            }
            Conn.ON -> {
                statusTv.text = "متصل است"; statusTv.setTextColor(green)
                val sec = ((System.currentTimeMillis() - VpnState.since) / 1000).coerceAtLeast(0)
                hintTv.text = "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
                ringColor = green
            }
        }
        powerCircle.background = rounded(Color.parseColor("#2A1170"), 0, ringColor, 6, true)
        val m = VpnState.message
        msgTv.visibility = if (m.isNotEmpty() && c == Conn.OFF) View.VISIBLE else View.GONE
        msgTv.text = m
    }
}
