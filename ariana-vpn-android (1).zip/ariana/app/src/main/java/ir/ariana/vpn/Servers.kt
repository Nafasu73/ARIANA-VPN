package ir.ariana.vpn

data class Server(val name: String, val flag: String, val args: List<String>)

/**
 * Every entry is a real Aether launch profile.
 * - "Auto" uses MASQUE (looks like normal HTTPS/QUIC), usually best on Irancell/Rightel.
 * - Country entries use the Psiphon transport pinned to that exit region.
 */
object Servers {
    val list = listOf(
        Server("خودکار (پیشنهادی)", "🌐", listOf("--masque", "-4", "--scan", "balanced", "--noize", "firewall")),
        Server("پایدار (Gool)", "🛡️", listOf("--gool")),
        Server("آلمان", "🇩🇪", listOf("--psiphon", "--psiphon-region", "DE")),
        Server("آمریکا", "🇺🇸", listOf("--psiphon", "--psiphon-region", "US")),
        Server("هلند", "🇳🇱", listOf("--psiphon", "--psiphon-region", "NL")),
        Server("فرانسه", "🇫🇷", listOf("--psiphon", "--psiphon-region", "FR")),
        Server("ترکیه", "🇹🇷", listOf("--psiphon", "--psiphon-region", "TR")),
        Server("کانادا", "🇨🇦", listOf("--psiphon", "--psiphon-region", "CA")),
        Server("انگلیس", "🇬🇧", listOf("--psiphon", "--psiphon-region", "GB")),
    )

    val instagramPackages = listOf(
        "com.instagram.android",
        "com.instagram.lite",
        "com.instagram.barcelona"
    )
}
