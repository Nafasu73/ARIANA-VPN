package com.ariana.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080516)
private val Panel = Color(0xFF21123E)
private val Purple = Color(0xFF8B19F5)
private val Pink = Color(0xFFD35BFF)
private val Gold = Color(0xFFFFD36A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArianaApp() }
    }
}

@Composable
fun ArianaApp() {
    var tab by remember { mutableStateOf("خانه") }
    var selectedServer by remember { mutableStateOf("آلمان 🇩🇪") }
    var connected by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("☰", color = Color.White, fontSize = 25.sp)
                Text("👑  ARIANA VPN", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Icon(Icons.Default.Notifications, null, tint = Pink)
            }
            when (tab) {
                "خانه" -> HomeScreen(connected, selectedServer,
                    onToggle = { connected = !connected },
                    onServer = { tab = "سرورها" })
                "سرورها" -> ServersScreen(selectedServer) { selectedServer = it; tab = "خانه" }
                "طرح‌ها" -> PlansScreen()
                else -> ProfileScreen()
            }
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF170D2C)).padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf("خانه", "کاربری", "طرح‌ها", "تنظیمات").forEach { item ->
                    Column(
                        Modifier.clickable { tab = item }.padding(horizontal = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val icon = when(item) {
                            "خانه" -> Icons.Default.Home
                            "کاربری" -> Icons.Default.Person
                            "طرح‌ها" -> Icons.Default.CardGiftcard
                            else -> Icons.Default.Settings
                        }
                        Icon(icon, null, tint = if(tab == item) Pink else Color.LightGray)
                        Text(item, color = if(tab == item) Pink else Color.LightGray, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(connected: Boolean, server: String, onToggle: () -> Unit, onServer: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🇮🇷", fontSize = 30.sp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("وضعیت اتصال", color = Color.LightGray)
                    Text(if(connected) "نمایشی: متصل" else "قطع است", color = if(connected) Color.Green else Color(0xFFFF5370), fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(35.dp))
        Box(
            Modifier.size(170.dp).background(
                Brush.radialGradient(listOf(Pink, Purple, Color(0xFF32106B))),
                RoundedCornerShape(100.dp)
            ).clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PowerSettingsNew, null, tint = Color.White, modifier = Modifier.size(82.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(if(connected) "اتصال نمایشی فعال است" else "برای آزمایش ظاهر، کلیک کنید", color = Color.White, fontSize = 17.sp)
        Text("این دکمه هنوز به سرور VPN وصل نیست.", color = Color(0xFFFFD36A), fontSize = 12.sp)
        Spacer(Modifier.height(28.dp))
        Card(
            Modifier.fillMaxWidth().clickable { onServer() },
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(18.dp)
        ) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Language, null, tint = Pink)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("انتخاب سرور", color = Color.LightGray)
                    Text(server, color = Color.White, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Pink)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Feature(Icons.Default.BarChart, "سرعت")
            Feature(Icons.Default.Dns, "سرورها")
            Feature(Icons.Default.CardGiftcard, "هدایا")
            Feature(Icons.Default.HeadsetMic, "پشتیبانی")
        }
    }
}

@Composable
fun Feature(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Pink, modifier = Modifier.size(30.dp))
        Text(label, color = Color.LightGray, fontSize = 12.sp)
    }
}

@Composable
fun ServersScreen(selected: String, onSelect: (String) -> Unit) {
    val servers = listOf("آلمان 🇩🇪", "ترکیه 🇹🇷", "فرانسه 🇫🇷", "هلند 🇳🇱", "کانادا 🇨🇦")
    Column(Modifier.padding(18.dp)) {
        Text("لیست سرورها", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(15.dp))
        servers.forEach { server ->
            Card(
                Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onSelect(server) },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(server, modifier = Modifier.weight(1f), color = Color.White, fontSize = 17.sp)
                    Text(if(server == selected) "● انتخاب شده" else "○", color = if(server == selected) Color.Green else Pink)
                }
            }
        }
    }
}

@Composable
fun PlansScreen() {
    Column(Modifier.padding(18.dp)) {
        Text("خرید اشتراک", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        listOf("اشتراک ۱ ماهه", "اشتراک ۳ ماهه", "اشتراک ۶ ماهه").forEach {
            Card(Modifier.fillMaxWidth().padding(vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(18.dp)) {
                    Text(it, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("قیمت پس از راه‌اندازی درگاه پرداخت تعیین می‌شود", color = Gold, fontSize = 12.sp)
                }
            }
        }
        Text("پرداخت آنلاین هنوز فعال نشده است.", color = Color(0xFFFFD36A), fontSize = 12.sp)
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("👑", fontSize = 48.sp)
        Text("ArianaUser", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("کاربر عادی", color = Pink)
        Spacer(Modifier.height(18.dp))
        Text("موجودی سکه: ۰", color = Gold)
        Text("سازنده: فاطمه زهرا ساعی", color = Color.White)
        Spacer(Modifier.height(12.dp))
        Text("برای فعال‌سازی امکانات واقعی، سرور و پنل مدیریت لازم است.", color = Color.LightGray)
    }
}
